package com.example.gunsmod;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Server -> client: the shooter's bullet hit something (drives the hit counter + damage numbers). */
public record HitPayload(float damage, boolean head) implements CustomPacketPayload {
    public static final Type<HitPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(GunsMod.MODID, "hit"));
    public static final StreamCodec<ByteBuf, HitPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.FLOAT, HitPayload::damage, ByteBufCodecs.BOOL, HitPayload::head, HitPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
