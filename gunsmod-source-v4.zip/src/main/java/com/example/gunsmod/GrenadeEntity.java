package com.example.gunsmod;

import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/** Bouncing frag grenade: explodes after a short fuse, hurts entities, never breaks blocks. */
public class GrenadeEntity extends ThrowableItemProjectile {
    private int fuse = 50;

    public GrenadeEntity(EntityType<? extends GrenadeEntity> type, Level level) {
        super(type, level);
    }

    public GrenadeEntity(Level level, LivingEntity owner) {
        super(GunsMod.GRENADE_ENTITY.get(), owner, level);
    }

    @Override
    protected Item getDefaultItem() {
        return GunsMod.GRENADE.get();
    }

    /** Lobs the grenade so that it lands next to {@code target}; {@code high} uses a steep arc to clear walls. */
    public void lobAt(Vec3 from, Vec3 target, boolean high) {
        double dx = target.x - from.x, dz = target.z - from.z;
        double x = Math.sqrt(dx * dx + dz * dz);
        double dy = target.y - from.y;
        double theta = Math.toRadians(high ? 62.0 : 42.0);
        double g = 0.03;
        double denom = 2.0 * Math.cos(theta) * Math.cos(theta) * (x * Math.tan(theta) - dy);
        double v = denom > 0.001 ? Math.sqrt(g * x * x / denom) * 1.07 : 1.0;
        v = Math.min(v, 1.9);
        Vec3 h = x < 0.001 ? new Vec3(0, 0, 1) : new Vec3(dx / x, 0, dz / x);
        this.setPos(from);
        this.setDeltaMovement(h.x * v * Math.cos(theta), v * Math.sin(theta), h.z * v * Math.cos(theta));
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            if (this.tickCount % 2 == 0) {
                this.level().addParticle(ParticleTypes.SMOKE, getX(), getY() + 0.15, getZ(), 0, 0.01, 0);
            }
            return;
        }
        if (this.tickCount == 2) {
            this.level().playSound(null, getX(), getY(), getZ(), SoundEvents.FLINTANDSTEEL_USE, SoundSource.NEUTRAL, 0.8f, 1.6f);
        }
        if (this.tickCount % 10 == 0) {
            this.level().playSound(null, getX(), getY(), getZ(), SoundEvents.FIRE_EXTINGUISH, SoundSource.NEUTRAL, 0.25f, 2.0f);
        }
        if (--fuse <= 0) explode();
    }

    private void explode() {
        if (!(this.level() instanceof ServerLevel sl)) return;
        Vec3 c = this.position().add(0, 0.2, 0);
        sl.explode(this.getOwner(), null, null, c.x, c.y, c.z, 3.0f, false, Level.ExplosionInteraction.NONE,
                GunsMod.P_FLASH_L.get(), GunsMod.P_FLASH_L.get(), SoundEvents.GENERIC_EXPLODE);
        GunItem.blastFx(sl, c, new Vec3(0, 1, 0), null);
        this.discard();
    }

    @Override
    protected void onHitBlock(BlockHitResult r) {
        Direction d = r.getDirection();
        Vec3 n = new Vec3(d.getStepX(), d.getStepY(), d.getStepZ());
        Vec3 v = this.getDeltaMovement();
        Vec3 nv = v.subtract(n.scale(2.0 * v.dot(n))).scale(0.45);
        this.setPos(r.getLocation().add(n.scale(0.08)));
        this.setDeltaMovement(nv.lengthSqr() < 0.002 ? Vec3.ZERO : nv);
        if (!this.level().isClientSide && v.lengthSqr() > 0.04) {
            this.level().playSound(null, getX(), getY(), getZ(), SoundEvents.IRON_GOLEM_STEP, SoundSource.NEUTRAL, 0.5f, 1.8f);
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult r) {
        this.setDeltaMovement(this.getDeltaMovement().scale(-0.2));
    }

    @Override
    public void addAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Fuse", fuse);
    }

    @Override
    public void readAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Fuse")) fuse = tag.getInt("Fuse");
    }
}
