package com.example.gunsmod;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.ModelEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import org.lwjgl.glfw.GLFW;

@EventBusSubscriber(modid = GunsMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    public static final KeyMapping RELOAD = new KeyMapping("key.gunsmod.reload", GLFW.GLFW_KEY_R, "key.categories.gunsmod");
    public static final KeyMapping AIM = new KeyMapping("key.gunsmod.aim", GLFW.GLFW_KEY_Z, "key.categories.gunsmod");

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(RELOAD);
        e.register(AIM);
    }

    @SubscribeEvent
    public static void registerScreens(RegisterMenuScreensEvent e) {
        e.register(GunsMod.WORKBENCH_MENU.get(), GunWorkbenchScreen::new);
        e.register(GunsMod.CUSTOMIZER_MENU.get(), GunCustomizerScreen::new);
        e.register(GunsMod.RESPAWNER_MENU.get(), RespawnerScreen::new);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(GunsMod.GUN_BOT.get(), GunBotRenderer::new);
        e.registerEntityRenderer(GunsMod.GRENADE_ENTITY.get(), net.minecraft.client.renderer.entity.ThrownItemRenderer::new);
    }

    @SubscribeEvent
    public static void registerParticles(RegisterParticleProvidersEvent e) {
        e.registerSpriteSet(GunsMod.P_SMOKE_S.get(), sp -> new GunParticle.Provider(sp, GunParticle.Kind.SMOKE_S));
        e.registerSpriteSet(GunsMod.P_SMOKE_M.get(), sp -> new GunParticle.Provider(sp, GunParticle.Kind.SMOKE_M));
        e.registerSpriteSet(GunsMod.P_SMOKE_L.get(), sp -> new GunParticle.Provider(sp, GunParticle.Kind.SMOKE_L));
        e.registerSpriteSet(GunsMod.P_DUST.get(), sp -> new GunParticle.Provider(sp, GunParticle.Kind.DUST));
        e.registerSpriteSet(GunsMod.P_FLASH_S.get(), sp -> new GunParticle.Provider(sp, GunParticle.Kind.FLASH_S));
        e.registerSpriteSet(GunsMod.P_FLASH_L.get(), sp -> new GunParticle.Provider(sp, GunParticle.Kind.FLASH_L));
        e.registerSpriteSet(GunsMod.P_SPARK.get(), sp -> new GunParticle.Provider(sp, GunParticle.Kind.SPARK));
        e.registerSpriteSet(GunsMod.P_FIRE.get(), sp -> new GunParticle.Provider(sp, GunParticle.Kind.FIRE));
    }

    @SubscribeEvent
    public static void registerGunModels(ModelEvent.RegisterAdditional e) {
        for (GunType t : GunType.values()) {
            for (int p = 0; p < Paints.COUNT; p++) e.register(GunItemRenderer.mrl(GunItemRenderer.gunModelName(t, p)));
        }
        for (int i = 1; i <= 6; i++) e.register(GunItemRenderer.mrl("gunmodel/part/optic_" + i));
        for (int i = 1; i <= 5; i++) e.register(GunItemRenderer.mrl("gunmodel/part/muzzle_" + i));
        for (int i = 1; i <= 4; i++) e.register(GunItemRenderer.mrl("gunmodel/part/under_" + i));
    }

    private static GunItemRenderer gunRenderer;

    @SubscribeEvent
    public static void registerItemExtensions(RegisterClientExtensionsEvent e) {
        IClientItemExtensions gunHold = new IClientItemExtensions() {
            @Override
            public net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer getCustomRenderer() {
                if (gunRenderer == null) gunRenderer = new GunItemRenderer();
                return gunRenderer;
            }

            @Override
            public HumanoidModel.ArmPose getArmPose(LivingEntity entity, InteractionHand hand, ItemStack stack) {
                return hand == InteractionHand.MAIN_HAND ? HumanoidModel.ArmPose.BOW_AND_ARROW : null;
            }
        };
        for (var h : GunsMod.ITEMS.getEntries()) {
            if (h.get() instanceof GunItem) e.registerItem(gunHold, h.get());
        }
    }
}
