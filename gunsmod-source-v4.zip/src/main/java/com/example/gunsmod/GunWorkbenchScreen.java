package com.example.gunsmod;

import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

public class GunWorkbenchScreen extends AbstractContainerScreen<GunWorkbenchMenu> {
    private static final int ROW = 24;
    private static final int LIST_X = 10;
    private static final int LIST_Y = 46;
    private static final int LIST_W = 170;

    private int selected = 0;
    private int scroll = 0;
    private float yaw = 152f;
    private float pitch = 10f;
    private boolean dragged = false;

    public GunWorkbenchScreen(GunWorkbenchMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
    }

    @Override
    protected void init() {
        this.imageWidth = this.width;
        this.imageHeight = this.height;
        super.init();
        this.leftPos = 0;
        this.topPos = 0;
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mx, int my) {
    }

    private int visibleRows() {
        return Math.max(3, (height - LIST_Y - 10) / ROW);
    }

    private int px() {
        return LIST_X + LIST_W + 16;
    }

    private int previewH() {
        return Math.max(90, Math.min(170, (int) (height * 0.38f)));
    }

    private int infoY() {
        return 30 + previewH() + 8;
    }

    private int btnY() {
        WorkbenchRecipes.Entry e = WorkbenchRecipes.all().get(selected);
        int perRow = Math.max(1, (width - px() - 12) / 84);
        int rows = (e.costs().size() + perRow - 1) / perRow;
        return infoY() + 16 + 14 + 14 + rows * 22 + 6;
    }

    private boolean canCraft() {
        WorkbenchRecipes.Entry e = WorkbenchRecipes.all().get(selected);
        return minecraft != null && minecraft.player != null && WorkbenchRecipes.canAfford(minecraft.player, e.costs());
    }

    @Override
    protected void renderBg(GuiGraphics g, float pt, int mx, int my) {
        GunUi.background(g, width, height);
        List<WorkbenchRecipes.Entry> list = WorkbenchRecipes.all();

        GunUi.label(g, font, "WORKSHOP", 10, 9);
        GunUi.text(g, font, "Gun Workbench", 10, 20, 1.7f, GunUi.TXT);

        // ---- list
        int vis = visibleRows();
        scroll = Math.max(0, Math.min(scroll, Math.max(0, list.size() - vis)));
        GunUi.panel(g, LIST_X - 2, LIST_Y - 3, LIST_X + LIST_W + 2, LIST_Y + vis * ROW + 1);
        for (int i = 0; i < vis && scroll + i < list.size(); i++) {
            int idx = scroll + i;
            int ry = LIST_Y + i * ROW;
            boolean sel = idx == selected;
            boolean hov = mx >= LIST_X && mx < LIST_X + LIST_W && my >= ry && my < ry + ROW - 1;
            if (sel) {
                g.fill(LIST_X, ry, LIST_X + LIST_W, ry + ROW - 2, 0xFFB57A1E);
                g.fill(LIST_X, ry, LIST_X + 2, ry + ROW - 2, GunUi.AMBER);
            } else if (hov) {
                g.fill(LIST_X, ry, LIST_X + LIST_W, ry + ROW - 2, 0x30FFFFFF);
            }
            ItemStack icon = new ItemStack(list.get(idx).result().get());
            g.renderItem(icon, LIST_X + 6, ry + 3);
            g.drawString(font, icon.getHoverName(), LIST_X + 28, ry + 8, sel ? 0xFFFFFFFF : 0xFFC4C9D2, false);
        }
        if (list.size() > vis) {
            int th = vis * ROW;
            int bh = Math.max(12, th * vis / list.size());
            int by = LIST_Y + (th - bh) * scroll / Math.max(1, list.size() - vis);
            g.fill(LIST_X + LIST_W - 1, by, LIST_X + LIST_W + 1, by + bh, 0xFF6C737E);
        }

        // ---- right side
        int px = px();
        int pw = width - px - 12;
        int ph = previewH();
        GunUi.panel(g, px, 30, px + pw, 30 + ph);

        WorkbenchRecipes.Entry e = list.get(selected);
        ItemStack out = new ItemStack(e.result().get(), e.count());
        int iy = infoY();
        GunUi.text(g, font, out.getHoverName().getString(), px, iy, 1.6f, GunUi.TXT);
        String sub;
        if (e.gun() != null) {
            GunType t = e.gun();
            String ammo = GunsMod.AMMO_ITEMS.get(t).get().getDescription().getString();
            String dmg = String.format(Locale.ROOT, "%.1f dmg", t.damage) + (t.pellets > 1 ? " x" + t.pellets : "");
            sub = ammo + "  ·  " + dmg + "  ·  " + (int) (1200f / t.fireDelay) + " rpm  ·  " + t.magSize + " rds";
        } else {
            sub = "Ammunition  ·  x" + e.count() + " per craft";
        }
        GunUi.text(g, font, sub, px, iy + 16, 0.9f, GunUi.DIM);

        GunUi.label(g, font, "Requires", px, iy + 30);
        boolean creative = minecraft != null && minecraft.player != null && minecraft.player.getAbilities().instabuild;
        int perRow = Math.max(1, pw / 84);
        for (int i = 0; i < e.costs().size(); i++) {
            WorkbenchRecipes.Cost c = e.costs().get(i);
            int cx = px + (i % perRow) * 84;
            int cy = iy + 44 + (i / perRow) * 22;
            g.fill(cx, cy, cx + 80, cy + 20, 0x90181C24);
            g.fill(cx, cy + 19, cx + 80, cy + 20, GunUi.LINE);
            g.renderItem(new ItemStack(c.item().get()), cx + 2, cy + 2);
            int have = minecraft != null && minecraft.player != null ? WorkbenchRecipes.count(minecraft.player, c.item().get()) : 0;
            boolean ok = creative || have >= c.count();
            g.drawString(font, (creative ? "∞" : String.valueOf(have)) + "/" + c.count(), cx + 22, cy + 6, ok ? GunUi.GREEN : GunUi.RED, false);
        }

        int by = btnY();
        boolean can = canCraft();
        boolean hovC = mx >= px && mx < px + 110 && my >= by && my < by + 20;
        g.fill(px, by, px + 110, by + 20, can ? (hovC ? 0xFFF0B040 : GunUi.AMBER) : 0xFF4A4F58);
        String label = can ? "Craft" : "Missing items";
        g.drawString(font, label, px + (110 - font.width(label)) / 2, by + 6, can ? 0xFF1A1305 : 0xFFA0A6B0, false);
        boolean hov5 = mx >= px + 116 && mx < px + 164 && my >= by && my < by + 20;
        g.fill(px + 116, by, px + 164, by + 20, can ? (hov5 ? 0xFFF0B040 : GunUi.AMBER) : 0xFF4A4F58);
        g.drawString(font, "x5", px + 116 + (48 - font.width("x5")) / 2, by + 6, can ? 0xFF1A1305 : 0xFFA0A6B0, false);

        // ---- 3D preview last (it sits above the 2D layer)
        float sway = dragged ? 0f : (float) Math.sin((minecraft != null ? minecraft.player.tickCount : 0) * 0.03 + pt * 0.03) * 7f;
        if (e.gun() != null) {
            float sc = Math.min(pw * 0.9f, ph * 2.2f);
            GunUi.gun(g, out, px + pw / 2f, 30 + ph / 2f, sc, yaw + sway, pitch);
        } else {
            g.pose().pushPose();
            g.pose().translate(px + pw / 2f - 40, 30 + ph / 2f - 40, 0);
            g.pose().scale(5f, 5f, 1f);
            g.renderItem(out, 0, 0);
            g.pose().popPose();
        }
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        super.render(g, mx, my, pt);
        List<WorkbenchRecipes.Entry> list = WorkbenchRecipes.all();
        int vis = visibleRows();
        for (int i = 0; i < vis && scroll + i < list.size(); i++) {
            int ry = LIST_Y + i * ROW;
            if (mx >= LIST_X && mx < LIST_X + LIST_W && my >= ry && my < ry + ROW - 1) {
                g.renderTooltip(font, new ItemStack(list.get(scroll + i).result().get()), mx, my);
            }
        }
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double dx, double dy) {
        scroll -= (int) Math.signum(dy);
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (mx >= px() && my >= 30 && my < 30 + previewH()) {
            yaw += (float) dx * 0.9f;
            pitch = Math.max(-40f, Math.min(50f, pitch + (float) dy * 0.5f));
            dragged = true;
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        List<WorkbenchRecipes.Entry> list = WorkbenchRecipes.all();
        int vis = visibleRows();
        for (int i = 0; i < vis && scroll + i < list.size(); i++) {
            int ry = LIST_Y + i * ROW;
            if (mx >= LIST_X && mx < LIST_X + LIST_W && my >= ry && my < ry + ROW - 1) {
                selected = scroll + i;
                return true;
            }
        }
        int px = px();
        int by = btnY();
        if (my >= by && my < by + 20 && canCraft() && minecraft != null && minecraft.gameMode != null) {
            if (mx >= px && mx < px + 110) {
                minecraft.gameMode.handleInventoryButtonClick(menu.containerId, selected);
                return true;
            }
            if (mx >= px + 116 && mx < px + 164) {
                for (int i = 0; i < 5; i++) minecraft.gameMode.handleInventoryButtonClick(menu.containerId, selected);
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }
}
