package com.example.gunsmod;

import com.mojang.blaze3d.platform.Lighting;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** Small drawing helpers shared by the workbench / customizer screens (client only). */
public final class GunUi {
    public static final int AMBER = 0xFFE0A030;
    public static final int TXT = 0xFFE8EAEE;
    public static final int DIM = 0xFF8A919C;
    public static final int PANEL = 0xB0141820;
    public static final int LINE = 0xFF2A303A;
    public static final int RED = 0xFFE05A4A;
    public static final int GREEN = 0xFF5CE070;

    private GunUi() {}

    public static void background(GuiGraphics g, int w, int h) {
        g.fill(0, 0, w, h, 0xD00A0D12);
        for (int x = 0; x < w; x += 24) g.fill(x, 0, x + 1, h, 0x12FFFFFF);
        for (int y = 0; y < h; y += 24) g.fill(0, y, w, y + 1, 0x12FFFFFF);
    }

    public static void panel(GuiGraphics g, int x0, int y0, int x1, int y1) {
        g.fill(x0, y0, x1, y1, PANEL);
        g.fill(x0, y0, x1, y0 + 1, LINE);
        g.fill(x0, y1 - 1, x1, y1, LINE);
        g.fill(x0, y0, x0 + 1, y1, LINE);
        g.fill(x1 - 1, y0, x1, y1, LINE);
    }

    public static void text(GuiGraphics g, Font f, String s, float x, float y, float scale, int color) {
        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(x, y, 0);
        ps.scale(scale, scale, 1f);
        g.drawString(f, s, 0, 0, color, false);
        ps.popPose();
    }

    public static void textRight(GuiGraphics g, Font f, String s, float xRight, float y, float scale, int color) {
        text(g, f, s, xRight - f.width(s) * scale, y, scale, color);
    }

    /** Small amber heading with a bullet, e.g. "• Requires". */
    public static void label(GuiGraphics g, Font f, String s, int x, int y) {
        g.fill(x, y + 1, x + 2, y + 6, AMBER);
        text(g, f, s, x + 5, y, 0.85f, AMBER);
    }

    /** Amber corner brackets around a rectangle (selection marker). */
    public static void brackets(GuiGraphics g, int x0, int y0, int x1, int y1, int c) {
        int l = 5;
        g.fill(x0, y0, x0 + l, y0 + 1, c); g.fill(x0, y0, x0 + 1, y0 + l, c);
        g.fill(x1 - l, y0, x1, y0 + 1, c); g.fill(x1 - 1, y0, x1, y0 + l, c);
        g.fill(x0, y1 - 1, x0 + l, y1, c); g.fill(x0, y1 - l, x0 + 1, y1, c);
        g.fill(x1 - l, y1 - 1, x1, y1, c); g.fill(x1 - 1, y1 - l, x1, y1, c);
    }

    /** Renders the item's real 3D model (rotatable). Call after the 2D parts of a screen. */
    public static void gun(GuiGraphics g, ItemStack stack, float cx, float cy, float scale, float yaw, float pitch) {
        Minecraft mc = Minecraft.getInstance();
        BakedModel model = mc.getItemRenderer().getModel(stack, mc.level, mc.player, 0);
        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(cx, cy, 120f);
        ps.scale(scale, -scale, scale);
        ps.translate(0f, 0.06f, 0f);
        ps.mulPose(Axis.XP.rotationDegrees(pitch));
        ps.mulPose(Axis.YP.rotationDegrees(yaw));
        Lighting.setupFor3DItems();
        mc.getItemRenderer().render(stack, ItemDisplayContext.GUI, false, ps, g.bufferSource(),
                15728880, OverlayTexture.NO_OVERLAY, model);
        g.flush();
        ps.popPose();
    }
}
