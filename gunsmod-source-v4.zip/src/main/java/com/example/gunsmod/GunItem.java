package com.example.gunsmod;

import java.util.function.Predicate;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.CustomModelData;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class GunItem extends Item {
    public final GunType type;

    public GunItem(Item.Properties props, GunType type) {
        super(props.stacksTo(1));
        this.type = type;
    }

    // ---------------------------------------------------------------- state
    public static int getAmmo(ItemStack stack, GunType type) {
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        return tag.contains("Ammo") ? tag.getInt("Ammo") : type.magSize;
    }

    public static void setAmmo(ItemStack stack, int ammo) {
        CustomData.update(DataComponents.CUSTOM_DATA, stack, t -> t.putInt("Ammo", ammo));
    }

    public static int getReload(ItemStack stack) {
        return stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getInt("Reload");
    }

    public static void setReload(ItemStack stack, int ticks) {
        CustomData.update(DataComponents.CUSTOM_DATA, stack, t -> t.putInt("Reload", ticks));
    }

    public static int getPaint(ItemStack stack) {
        return stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getInt("Paint");
    }

    public static int getScope(ItemStack stack) {
        return stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getInt("Scope");
    }

    public static int getMuzzle(ItemStack stack) {
        return stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getInt("Muzzle");
    }

    public static int getUnder(ItemStack stack) {
        return stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getInt("Under");
    }

    /** Ammo type: 0 FMJ, 1 hollow point, 2 armour piercing, 3 incendiary. */
    public static int getAmmoType(ItemStack stack) {
        return stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getInt("AmmoT");
    }

    public static boolean supportsMuzzle(GunType t) {
        return t != GunType.RPG && t != GunType.MINIGUN;
    }

    public static boolean supportsUnder(GunType t) {
        return t != GunType.RPG && t != GunType.MINIGUN && t != GunType.PISTOL && t != GunType.DEAGLE;
    }

    /** Packed attachment code: muzzle + 10 * underbarrel + 100 * ammo type. */
    public static int mods(ItemStack stack) {
        return getMuzzle(stack) + 10 * getUnder(stack) + 100 * getAmmoType(stack);
    }

    // muzzle: 1 suppressor 2 compensator 3 flash hider 4 muzzle brake 5 bayonet
    // under : 1 vertical grip 2 angled grip 3 laser 4 bipod      ammo: 1 HP 2 AP 3 incendiary
    public static float recoilMult(int c) {
        int m = c % 10, u = c / 10 % 10;
        float r = switch (m) { case 1 -> 0.9f; case 2 -> 0.55f; case 3 -> 0.85f; case 4 -> 0.65f; default -> 1f; };
        r *= switch (u) { case 1 -> 0.8f; case 2 -> 0.9f; case 4 -> 0.7f; default -> 1f; };
        return r;
    }

    public static float rangeMult(int c) {
        int m = c % 10, a = c / 100;
        return (m == 1 ? 0.9f : 1f) * (a == 1 ? 0.85f : a == 2 ? 1.1f : 1f);
    }

    public static float damageMult(int c) {
        int m = c % 10, a = c / 100;
        return (m == 1 ? 0.95f : 1f) * (a == 1 ? 1.2f : a == 2 ? 1.1f : a == 3 ? 0.9f : 1f) * (m == 5 ? 1f : 1f);
    }

    public static float spreadMult(int c) {
        int m = c % 10, u = c / 10 % 10;
        return (m == 2 ? 0.9f : m == 4 ? 0.95f : 1f) * (u == 1 ? 0.9f : u == 2 ? 1.05f : u == 3 ? 0.75f : u == 4 ? 0.85f : 1f);
    }

    /** FOV multiplier while aiming through an optic (lower = more zoom). */
    public static float scopeZoom(int scope) {
        return switch (scope) { case 1, 3 -> 0.8f; case 2 -> 0.45f; case 4 -> 0.55f; case 5 -> 0.22f; case 6 -> 0.4f; default -> 1f; };
    }

    /** Optics that replace the whole view with a lens. */
    public static boolean fullLens(int scope) {
        return scope == 2 || scope == 5 || scope == 6;
    }

    public static void setCosmetics(ItemStack stack, int paint, int scope) {
        setCosmetics(stack, paint, scope, getMuzzle(stack), getUnder(stack), getAmmoType(stack));
    }

    public static void setCosmetics(ItemStack stack, int paint, int scope, int muzzle, int under, int ammoT) {
        CustomData.update(DataComponents.CUSTOM_DATA, stack, t -> {
            t.putInt("Paint", paint);
            t.putInt("Scope", scope);
            t.putInt("Muzzle", muzzle);
            t.putInt("Under", under);
            t.putInt("AmmoT", ammoT);
        });
    }

    // ---------------------------------------------------------------- use
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResultHolder.pass(stack);
        }
        if (player.isShiftKeyDown()) { // sneak + right click = reload (handy on mobile)
            if (!level.isClientSide) {
                startReload(player, stack);
            }
            return InteractionResultHolder.fail(stack);
        }
        player.startUsingItem(hand);
        if (!level.isClientSide) {
            tryFire(level, player, stack);
        }
        return InteractionResultHolder.consume(stack);
    }

    // Both signatures are declared so it works whichever one this Minecraft version uses.
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        return 72000;
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
        if (!level.isClientSide && type.automatic && entity instanceof Player player) {
            tryFire(level, player, stack);
        }
    }

    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || oldStack.getItem() != newStack.getItem();
    }

    private void tryFire(Level level, Player player, ItemStack stack) {
        if (player.getCooldowns().isOnCooldown(this)) return;
        if (getReload(stack) > 0) return;
        int ammo = getAmmo(stack, type);
        if (ammo <= 0) {
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 0.8f, 1.2f);
            player.getCooldowns().addCooldown(this, 10);
            return;
        }
        boolean aiming = GunsMod.isAiming(player);
        shoot((ServerLevel) level, player, player.getEyePosition(), player.getLookAngle(),
                type, aiming, 1.0f, 0.0f, ignoreFor(player), mods(stack));
        setAmmo(stack, ammo - 1);
        player.getCooldowns().addCooldown(this, type.fireDelay);
    }

    public static Predicate<Entity> ignoreFor(Player player) {
        return e -> e instanceof GunBotEntity b && b.isAlly() && player.getUUID().equals(b.getOwnerUUID());
    }

    // ---------------------------------------------------------------- sounds
    private static void playShot(ServerLevel level, LivingEntity s, GunType t, int muzzle) {
        RandomSource r = level.random;
        float p = t.pitch * (0.95f + r.nextFloat() * 0.1f);
        double x = s.getX(), y = s.getEyeY(), z = s.getZ();
        if (muzzle % 10 == 1) { // suppressed: just a soft thump
            level.playSound(null, x, y, z, SoundEvents.DISPENSER_LAUNCH, SoundSource.PLAYERS, 0.6f, p * 1.5f);
            level.playSound(null, x, y, z, SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.PLAYERS, 0.25f, p * 1.9f);
            return;
        }
        switch (t.sound) {
            case 0 -> {
                level.playSound(null, x, y, z, SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.PLAYERS, 2.0f, p);
                level.playSound(null, x, y, z, SoundEvents.DISPENSER_LAUNCH, SoundSource.PLAYERS, 0.7f, p * 1.3f);
            }
            case 1 -> {
                level.playSound(null, x, y, z, SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.PLAYERS, 2.5f, p);
                level.playSound(null, x, y, z, SoundEvents.FIREWORK_ROCKET_LARGE_BLAST, SoundSource.PLAYERS, 1.2f, p * 1.4f);
                level.playSound(null, x, y, z, SoundEvents.DISPENSER_LAUNCH, SoundSource.PLAYERS, 1.0f, p * 0.6f);
            }
            default -> {
                level.playSound(null, x, y, z, SoundEvents.FIREWORK_ROCKET_LARGE_BLAST, SoundSource.PLAYERS, 3.0f, p);
                level.playSound(null, x, y, z, SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.PLAYERS, 2.0f, p * 0.7f);
                level.playSound(null, x, y, z, SoundEvents.PISTON_CONTRACT, SoundSource.PLAYERS, 1.0f, p * 0.5f);
            }
        }
    }

    // ---------------------------------------------------------------- shooting (shared with bots)
    public static void shoot(ServerLevel level, LivingEntity shooter, Vec3 origin, Vec3 dir, GunType type,
                             boolean aiming, float dmgMult, float extraSpread, Predicate<Entity> ignore) {
        shoot(level, shooter, origin, dir, type, aiming, dmgMult, extraSpread, ignore, 0);
    }

    public static void shoot(ServerLevel level, LivingEntity shooter, Vec3 origin, Vec3 dir, GunType type,
                             boolean aiming, float dmgMult, float extraSpread, Predicate<Entity> ignore, int muzzleDev) {
        RandomSource rnd = level.random;
        float spread = (type.spread * (aiming ? 0.3f : 1.0f) + extraSpread) * spreadMult(muzzleDev);
        double range = type.range * rangeMult(muzzleDev);
        dmgMult *= damageMult(muzzleDev);

        playShot(level, shooter, type, muzzleDev);
        Vec3 up = new Vec3(0, 1, 0);
        Vec3 right = dir.cross(up);
        right = right.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : right.normalize();
        Vec3 muzzle = origin.add(dir.scale(1.2)).add(right.scale(0.22)).add(0, -0.18, 0);
        muzzleFx(level, muzzle, origin, dir, type, muzzleDev);

        for (int i = 0; i < type.pellets; i++) {
            double f = spread * 0.0175;
            Vec3 d = dir.add(rnd.nextGaussian() * f, rnd.nextGaussian() * f, rnd.nextGaussian() * f).normalize();
            Vec3 end = origin.add(d.scale(range));

            BlockHitResult bhr = level.clip(new ClipContext(origin, end,
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, shooter));
            Vec3 stop = bhr.getType() == HitResult.Type.MISS ? end : bhr.getLocation();

            AABB box = new AABB(origin, stop).inflate(1.0);
            EntityHitResult ehr = ProjectileUtil.getEntityHitResult(level, shooter, origin, stop, box,
                    e -> e.isAlive() && !e.isSpectator() && e.isPickable() && e != shooter && !ignore.test(e));

            Vec3 impact = stop;
            boolean hitSomething = false;
            if (ehr != null) {
                hitSomething = true;
                impact = ehr.getLocation();
                Entity target = ehr.getEntity();
                float dmg = type.damage * dmgMult;
                boolean head = target instanceof LivingEntity le && impact.y >= le.getEyeY() - 0.15;
                if (head) dmg *= 1.5f;
                DamageSource src = shooter instanceof Player p
                        ? level.damageSources().playerAttack(p)
                        : level.damageSources().mobAttack(shooter);
                target.invulnerableTime = 0;
                target.hurt(src, dmg);
                if (muzzleDev / 100 == 3) target.igniteForSeconds(3);
                if (shooter instanceof ServerPlayer sp) {
                    sp.playNotifySound(SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.6f, head ? 2.0f : 1.4f);
                    net.neoforged.neoforge.network.PacketDistributor.sendToPlayer(sp, new HitPayload(dmg, head));
                }
            } else if (bhr.getType() != HitResult.Type.MISS) {
                hitSomething = true;
                BlockState bs = level.getBlockState(bhr.getBlockPos());
                Vec3 face = new Vec3(bhr.getDirection().getStepX(), bhr.getDirection().getStepY(), bhr.getDirection().getStepZ());
                impactFx(level, impact.add(face.scale(0.04)), face, bs, type.pellets > 1);
            }

            double dist = origin.distanceTo(impact);
            if (type.explosive > 0f) {
                // rocket exhaust trail: soft smoke puffs, no vanilla flame/large-smoke
                for (double t = 1.5; t < dist; t += 1.1) {
                    Vec3 p = origin.add(d.scale(t));
                    fx(level, GunsMod.P_SMOKE_M.get(), p, new Vec3(rnd.nextGaussian() * 0.004, 0.004 + rnd.nextDouble() * 0.01, rnd.nextGaussian() * 0.004));
                    if (rnd.nextInt(3) == 0) fx(level, GunsMod.P_SPARK.get(), p, cone(rnd, d.scale(-1), 0.5).scale(0.08 + rnd.nextDouble() * 0.12));
                }
                if (hitSomething) {
                    level.explode(shooter, null, null, impact.x, impact.y, impact.z,
                            type.explosive * Math.max(0.5f, dmgMult), false, Level.ExplosionInteraction.NONE,
                            GunsMod.P_FLASH_L.get(), GunsMod.P_FLASH_L.get(), SoundEvents.GENERIC_EXPLODE);
                    boolean blockHit = ehr == null && bhr.getType() != HitResult.Type.MISS;
                    BlockState under = blockHit ? level.getBlockState(bhr.getBlockPos()) : null;
                    Vec3 nrm = !blockHit ? new Vec3(0, 1, 0)
                            : new Vec3(bhr.getDirection().getStepX(), bhr.getDirection().getStepY(), bhr.getDirection().getStepZ());
                    blastFx(level, impact.add(nrm.scale(0.1)), nrm, under);
                }
            }
        }
    }

    // ---------------------------------------------------------------- realistic particles
    private static void fx(ServerLevel l, net.minecraft.core.particles.ParticleOptions p, Vec3 pos, Vec3 vel) {
        l.sendParticles(p, pos.x, pos.y, pos.z, 0, vel.x, vel.y, vel.z, 1.0);
    }

    /** Random direction inside a cone around dir (spread ~ tangent of the half angle). */
    private static Vec3 cone(RandomSource r, Vec3 dir, double spread) {
        Vec3 v = dir.add(r.nextGaussian() * spread, r.nextGaussian() * spread, r.nextGaussian() * spread);
        return v.lengthSqr() < 1.0E-6 ? dir : v.normalize();
    }

    private static void muzzleFx(ServerLevel l, Vec3 muzzle, Vec3 origin, Vec3 dir, GunType t, int dev) {
        RandomSource r = l.random;
        int w = t.sound; // 0 light, 1 medium, 2 heavy
        dev = dev % 10;
        if (dev == 1) { // suppressed: no flash, a little smoke
            fx(l, GunsMod.P_SMOKE_S.get(), muzzle, dir.scale(0.05));
            return;
        }
        if (dev != 3 && dev != 4) { // flash hider / brake hide most of the flash
            fx(l, GunsMod.P_FLASH_S.get(), muzzle, dir.scale(0.01));
            if (w >= 1) fx(l, GunsMod.P_FLASH_S.get(), muzzle.add(dir.scale(0.2)), dir.scale(0.01));
        }
        for (int i = 0; i < 3 + w * 2; i++) {
            fx(l, GunsMod.P_SMOKE_S.get(), muzzle.add(dir.scale(r.nextDouble() * 0.2)),
                    dir.scale(0.04 + r.nextDouble() * 0.12).add(r.nextGaussian() * 0.01, 0.005 + r.nextDouble() * 0.01, r.nextGaussian() * 0.01));
        }
        for (int i = 0; i < 1 + w; i++) {
            fx(l, GunsMod.P_SMOKE_M.get(), muzzle.add(dir.scale(0.1)),
                    dir.scale(0.02 + r.nextDouble() * 0.04).add(r.nextGaussian() * 0.006, 0.006, r.nextGaussian() * 0.006));
        }
        for (int i = 0; i < 3 + w * 2; i++) {
            fx(l, GunsMod.P_SPARK.get(), muzzle, cone(r, dir, 0.35).scale(0.3 + r.nextDouble() * 0.5));
        }
        if (t.explosive > 0f) { // RPG back-blast
            Vec3 back = dir.scale(-1);
            Vec3 bp = origin.add(dir.scale(-0.4)).add(0, -0.2, 0);
            fx(l, GunsMod.P_FLASH_S.get(), bp, back.scale(0.01));
            for (int i = 0; i < 8; i++) {
                fx(l, GunsMod.P_SMOKE_M.get(), bp, cone(r, back, 0.45).scale(0.1 + r.nextDouble() * 0.18));
            }
            for (int i = 0; i < 6; i++) {
                fx(l, GunsMod.P_FIRE.get(), bp, cone(r, back, 0.4).scale(0.08 + r.nextDouble() * 0.1));
            }
        }
    }

    private static void impactFx(ServerLevel l, Vec3 p, Vec3 n, BlockState bs, boolean multi) {
        RandomSource r = l.random;
        l.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, bs), p.x, p.y, p.z,
                multi ? 3 : 8, 0.05, 0.05, 0.05, 0.16);
        for (int i = 0; i < (multi ? 1 : 3); i++) {
            fx(l, GunsMod.P_DUST.get(), p, n.scale(0.02 + r.nextDouble() * 0.05).add(r.nextGaussian() * 0.015, r.nextGaussian() * 0.015, r.nextGaussian() * 0.015));
        }
        if (!multi) {
            fx(l, GunsMod.P_SMOKE_S.get(), p, n.scale(0.02).add(0, 0.01, 0));
        }
        for (int i = 0; i < (multi ? 1 : 4); i++) {
            fx(l, GunsMod.P_SPARK.get(), p, cone(r, n, 0.7).scale(0.2 + r.nextDouble() * 0.45));
        }
    }

    /** Realistic rocket detonation: white-hot flash, rolling fireball, dark smoke column, dust ring, embers and debris. */
    static void blastFx(ServerLevel l, Vec3 c, Vec3 n, BlockState bs) {
        RandomSource r = l.random;
        fx(l, GunsMod.P_FLASH_L.get(), c.add(n.scale(0.4)), Vec3.ZERO);
        for (int i = 0; i < 3; i++) { // extra fireball lobes for volume
            Vec3 o = new Vec3(r.nextGaussian() * 1.0, 0.3 + r.nextDouble() * 1.2, r.nextGaussian() * 1.0);
            fx(l, GunsMod.P_FLASH_L.get(), c.add(o), Vec3.ZERO);
        }
        for (int i = 0; i < 12; i++) {
            Vec3 d = cone(r, n.add(0, 0.35, 0), 0.9);
            fx(l, GunsMod.P_FIRE.get(), c.add(d.scale(0.5 * r.nextDouble())), d.scale(0.05 + r.nextDouble() * 0.2));
        }
        for (int i = 0; i < 8; i++) {
            Vec3 o = new Vec3(r.nextGaussian() * 0.6, 0.5 + r.nextDouble() * 0.8, r.nextGaussian() * 0.6);
            fx(l, GunsMod.P_SMOKE_L.get(), c.add(o), new Vec3(r.nextGaussian() * 0.03, 0.04 + r.nextDouble() * 0.08, r.nextGaussian() * 0.03));
        }
        for (int i = 0; i < 12; i++) {
            Vec3 o = new Vec3(r.nextGaussian() * 0.9, r.nextDouble() * 1.2, r.nextGaussian() * 0.9);
            fx(l, GunsMod.P_SMOKE_M.get(), c.add(o), new Vec3(r.nextGaussian() * 0.06, 0.02 + r.nextDouble() * 0.07, r.nextGaussian() * 0.06));
        }
        for (int i = 0; i < 20; i++) { // low shockwave dust ring
            double a = i / 20.0 * Math.PI * 2 + r.nextDouble() * 0.2;
            Vec3 t1 = Math.abs(n.y) > 0.9 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
            Vec3 u = n.cross(t1).normalize();
            Vec3 v = n.cross(u).normalize();
            Vec3 dir = u.scale(Math.cos(a)).add(v.scale(Math.sin(a)));
            fx(l, GunsMod.P_DUST.get(), c.add(dir.scale(0.4)), dir.scale(0.22 + r.nextDouble() * 0.2).add(n.scale(0.02)));
        }
        for (int i = 0; i < 45; i++) {
            Vec3 d = cone(r, n.add(0, 0.5, 0), 1.0);
            fx(l, GunsMod.P_SPARK.get(), c, d.scale(0.4 + r.nextDouble() * 1.0));
        }
        if (bs != null) {
            l.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, bs), c.x, c.y, c.z, 40, 0.4, 0.3, 0.4, 0.35);
        }
    }

    // ---------------------------------------------------------------- reload
    public static void startReload(Player player, ItemStack stack) {
        if (!(stack.getItem() instanceof GunItem gun)) return;
        GunType type = gun.type;
        if (getReload(stack) > 0) return;
        if (getAmmo(stack, type) >= type.magSize) return;
        if (!player.getAbilities().instabuild && countAmmo(player, type) <= 0) {
            player.displayClientMessage(Component.literal("No " + GunsMod.AMMO_ITEMS.get(type).get().getDescription().getString() + "!").withStyle(ChatFormatting.RED), true);
            return;
        }
        setReload(stack, type.reloadTicks);
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.IRON_TRAPDOOR_OPEN, SoundSource.PLAYERS, 0.8f, 1.4f);
    }

    public static int countAmmo(Player player, GunType type) {
        Item ammoItem = GunsMod.AMMO_ITEMS.get(type).get();
        int n = 0;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack s = player.getInventory().getItem(i);
            if (s.is(ammoItem)) n += s.getCount();
        }
        return n;
    }

    private static int takeAmmo(Player player, GunType type, int wanted) {
        Item ammoItem = GunsMod.AMMO_ITEMS.get(type).get();
        int taken = 0;
        for (int i = 0; i < player.getInventory().getContainerSize() && taken < wanted; i++) {
            ItemStack s = player.getInventory().getItem(i);
            if (s.is(ammoItem)) {
                int t = Math.min(s.getCount(), wanted - taken);
                s.shrink(t);
                taken += t;
            }
        }
        return taken;
    }

    private void finishReload(Player player, ItemStack stack) {
        int current = getAmmo(stack, type);
        int need = type.magSize - current;
        int got = player.getAbilities().instabuild ? need : takeAmmo(player, type, need);
        setAmmo(stack, current + got);
        setReload(stack, 0);
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.PLAYERS, 0.9f, 1.6f);
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.IRON_DOOR_CLOSE, SoundSource.PLAYERS, 0.4f, 1.8f);
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (level.isClientSide || !(entity instanceof Player player)) return;
        int r = getReload(stack);
        if (r > 0) {
            if (!selected) {
                setReload(stack, 0); // switched weapon: reload cancelled
            } else if (r - 1 <= 0) {
                finishReload(player, stack);
            } else {
                if (r - 1 == type.reloadTicks / 2) {
                    level.playSound(null, player.getX(), player.getY(), player.getZ(),
                            SoundEvents.PISTON_EXTEND, SoundSource.PLAYERS, 0.4f, 1.8f);
                }
                setReload(stack, r - 1);
            }
        }
        if (selected) {
            int amp = -1;
            boolean sprint = player.isSprinting();
            if (GunsMod.isAiming(player)) amp = 1;
            if (type.heavy) {
                amp = Math.max(amp, sprint ? 2 : 0);
            } else if (sprint) {
                amp = Math.max(amp, 1);
            }
            if (amp >= 0) {
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 5, amp, false, false, false));
            }
        }
    }
}
