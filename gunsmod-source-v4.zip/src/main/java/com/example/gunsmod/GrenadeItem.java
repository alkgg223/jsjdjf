package com.example.gunsmod;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class GrenadeItem extends Item {
    public GrenadeItem(Item.Properties props) {
        super(props.stacksTo(16));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack st = player.getItemInHand(hand);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.SNOWBALL_THROW, SoundSource.PLAYERS, 0.6f, 0.7f);
        if (!level.isClientSide) {
            GrenadeEntity g = new GrenadeEntity(level, player);
            g.shootFromRotation(player, player.getXRot() - 8.0f, player.getYRot(), 0.0f, 1.2f, 0.8f);
            level.addFreshEntity(g);
        }
        player.getCooldowns().addCooldown(this, 25);
        if (!player.getAbilities().instabuild) st.shrink(1);
        return InteractionResultHolder.sidedSuccess(st, level.isClientSide);
    }
}
