package com.example.gunsmod;

import java.util.EnumSet;
import java.util.UUID;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import java.util.List;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class GunBotEntity extends PathfinderMob {
    private static final EntityDataAccessor<Boolean> ALLY =
            SynchedEntityData.defineId(GunBotEntity.class, EntityDataSerializers.BOOLEAN);

    private UUID ownerUUID;
    private int ammo;
    private int reloadTicks;
    private int shootCooldown;

    // loadout: [0] primary, [1] sidearm; the active one is in the main hand
    private final ItemStack[] weapons = {ItemStack.EMPTY, ItemStack.EMPTY};
    private final int[] ammoStore = new int[2];
    private int active = 0;
    private int switchCd = 400;
    private boolean hasGrenade;
    private int grenadeCd;
    private int grenadeHold;
    private boolean noLoot;
    private BlockPos machinePos;

    public GunBotEntity(EntityType<? extends GunBotEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.setDropChance(EquipmentSlot.MAINHAND, 2.0f);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 30.0)
                .add(Attributes.MOVEMENT_SPEED, 0.28)
                .add(Attributes.FOLLOW_RANGE, 40.0)
                .add(Attributes.ARMOR, 2.0);
    }

    @Override
    public EntityDimensions getDefaultDimensions(Pose pose) {
        return switch (pose) {
            case CROUCHING -> EntityDimensions.scalable(0.6f, 1.5f).withEyeHeight(1.27f);
            case SWIMMING -> EntityDimensions.scalable(0.6f, 0.6f).withEyeHeight(0.4f);
            default -> super.getDefaultDimensions(pose);
        };
    }

    public boolean isProne() {
        return this.hasPose(Pose.SWIMMING);
    }

    public void reloadNow() {
        GunItem g = getGun();
        if (g != null && reloadTicks == 0 && ammo < g.type.magSize) {
            reloadTicks = g.type.reloadTicks;
            this.level().playSound(null, getX(), getY(), getZ(), SoundEvents.IRON_TRAPDOOR_OPEN, SoundSource.HOSTILE, 0.8f, 1.4f);
        }
    }

    public int ammoLeft() {
        return ammo;
    }

    public boolean isReloading() {
        return reloadTicks > 0;
    }

    public boolean hasAnyGun() {
        return weapons[0].getItem() instanceof GunItem || weapons[1].getItem() instanceof GunItem;
    }

    public boolean isMachineBound() {
        return machinePos != null;
    }

    public void setMachinePos(BlockPos p) {
        this.machinePos = p;
    }

    public void setNoLoot(boolean v) {
        this.noLoot = v;
    }

    private void equip(int slot) {
        if (slot == active && this.getMainHandItem() == weapons[slot]) return;
        ammoStore[active] = ammo;
        active = slot;
        ammo = ammoStore[slot];
        reloadTicks = 0;
        this.setItemSlot(EquipmentSlot.MAINHAND, weapons[slot]);
        this.level().playSound(null, getX(), getY(), getZ(), SoundEvents.ARMOR_EQUIP_IRON.value(), SoundSource.HOSTILE, 0.6f, 1.5f);
    }

    private boolean has(int slot) {
        return weapons[slot].getItem() instanceof GunItem;
    }

    private static boolean heavy(GunType t) {
        return t == GunType.SNIPER || t == GunType.LMG || t == GunType.RPG || t == GunType.MINIGUN;
    }

    public boolean canThrowGrenade() {
        return hasGrenade && grenadeCd <= 0;
    }

    /** Lob a grenade at the target. Uses a high arc when the target is behind cover. */
    public void throwGrenade(LivingEntity target, boolean high) {
        if (!(this.level() instanceof ServerLevel sl)) return;
        GrenadeEntity g = new GrenadeEntity(sl, this);
        Vec3 from = this.getEyePosition().add(0, 0.1, 0);
        Vec3 to = target.position().add(target.getDeltaMovement().scale(6.0)).add(0, 0.1, 0);
        g.lobAt(from, to, high);
        sl.addFreshEntity(g);
        sl.playSound(null, getX(), getY(), getZ(), SoundEvents.SNOWBALL_THROW, SoundSource.HOSTILE, 0.7f, 0.7f);
        this.swing(InteractionHand.MAIN_HAND);
        grenadeCd = 800; // 40 seconds
        grenadeHold = 12;
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(GunsMod.GRENADE.get()));
    }

    public CompoundTag exportData(HolderLookup.Provider reg) {
        CompoundTag t = new CompoundTag();
        t.putBoolean("Ally", isAlly());
        if (ownerUUID != null) t.putUUID("Owner", ownerUUID);
        ammoStore[active] = ammo;
        for (int i = 0; i < 2; i++) {
            if (!weapons[i].isEmpty()) t.put("W" + i, weapons[i].save(reg));
            t.putInt("A" + i, ammoStore[i]);
        }
        t.putInt("Active", active);
        t.putBoolean("Grenade", hasGrenade);
        return t;
    }

    public void importData(CompoundTag t, HolderLookup.Provider reg) {
        this.entityData.set(ALLY, t.getBoolean("Ally"));
        if (t.hasUUID("Owner")) ownerUUID = t.getUUID("Owner");
        for (int i = 0; i < 2; i++) {
            weapons[i] = t.contains("W" + i) ? ItemStack.parse(reg, t.get("W" + i)).orElse(ItemStack.EMPTY) : ItemStack.EMPTY;
            ammoStore[i] = t.getInt("A" + i);
        }
        hasGrenade = t.getBoolean("Grenade");
        active = t.getInt("Active") == 1 && has(1) ? 1 : (has(0) ? 0 : 1);
        ammo = ammoStore[active];
        this.setItemSlot(EquipmentSlot.MAINHAND, weapons[active]);
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        if (!this.level().isClientSide && machinePos != null && reason.shouldDestroy()
                && this.level().getBlockEntity(machinePos) instanceof RespawnerBlockEntity be) {
            be.onBotGone(this.getUUID());
        }
        super.remove(reason);
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource src, boolean recent) {
        super.dropCustomDeathLoot(level, src, recent);
        if (noLoot) return;
        int other = 1 - active;
        if (has(other)) this.spawnAtLocation(weapons[other].copy());
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(ALLY, true);
    }

    // ------------------------------------------------------------ team
    public boolean isAlly() {
        return this.entityData.get(ALLY);
    }

    public void setAlly(boolean ally, UUID owner) {
        this.entityData.set(ALLY, ally);
        this.ownerUUID = ally ? owner : null;
        this.setTarget(null);
    }

    public UUID getOwnerUUID() {
        return ownerUUID;
    }

    public Player getOwner() {
        return ownerUUID == null ? null : this.level().getPlayerByUUID(ownerUUID);
    }

    public GunItem getGun() {
        return this.getMainHandItem().getItem() instanceof GunItem g ? g : null;
    }

    /** Entities this bot must never shoot or target. */
    public boolean isFriendly(Entity e) {
        if (e == this) return true;
        if (isAlly()) {
            if (ownerUUID != null && ownerUUID.equals(e.getUUID())) return true;
            return e instanceof GunBotEntity b && b.isAlly();
        }
        return e instanceof GunBotEntity b && !b.isAlly();
    }

    public boolean isHostileTo(LivingEntity e) {
        if (e == this || !e.isAlive() || isFriendly(e)) return false;
        if (isAlly()) {
            return e instanceof Enemy || (e instanceof GunBotEntity b && !b.isAlly());
        }
        return (e instanceof Player p && !p.isSpectator()) || (e instanceof GunBotEntity b && b.isAlly());
    }

    @Override
    public void setTarget(LivingEntity target) {
        if (target != null && isFriendly(target)) return;
        super.setTarget(target);
    }

    // ------------------------------------------------------------ AI
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new AttackGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0f));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 10, true, false, this::isHostileTo));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) return;
        if (shootCooldown > 0) shootCooldown--;
        if (grenadeCd > 0) grenadeCd--;
        if (grenadeHold > 0 && --grenadeHold == 0) this.setItemSlot(EquipmentSlot.MAINHAND, weapons[active]);
        if (noLoot) this.setDropChance(EquipmentSlot.MAINHAND, 0.0f);
        if (grenadeHold == 0 && --switchCd <= 0) {
            switchCd = 300 + getRandom().nextInt(300);
            if (has(0) && has(1)) equip(active == 0 ? 1 : 0);
        }
        if (grenadeHold == 0 && getTarget() != null && has(0) && has(1)) { // tactical swaps
            GunItem cur = getGun();
            double d = distanceTo(getTarget());
            if (active == 0 && cur != null && (heavy(cur.type) && d < 6.0 || ammo == 0 && ammoStore[1] > 0)) equip(1);
            else if (active == 1 && ammo == 0 && ammoStore[0] > 0) equip(0);
        }
        if (reloadTicks > 0 && --reloadTicks == 0) {
            GunItem g = getGun();
            if (g != null) ammo = g.type.magSize;
        }
        if (isAlly() && this.tickCount % 10 == 0 && getTarget() == null) {
            Player owner = getOwner();
            if (owner != null) {
                LivingEntity a = owner.getLastHurtByMob();
                if (a != null && a.isAlive() && !isFriendly(a)
                        && owner.tickCount - owner.getLastHurtByMobTimestamp() < 100) {
                    setTarget(a);
                } else {
                    LivingEntity b = owner.getLastHurtMob();
                    if (b != null && b.isAlive() && isHostileTo(b)
                            && owner.tickCount - owner.getLastHurtMobTimestamp() < 100) {
                        setTarget(b);
                    }
                }
            }
        }
    }

    public void tryShoot(LivingEntity target) {
        GunItem gun = getGun();
        if (gun == null || !(this.level() instanceof ServerLevel sl) || !target.isAlive()) return;
        if (reloadTicks > 0 || shootCooldown > 0 || grenadeHold > 0) return;
        if (ammo <= 0) {
            reloadTicks = gun.type.reloadTicks;
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.IRON_TRAPDOOR_OPEN, SoundSource.HOSTILE, 0.8f, 1.4f);
            return;
        }
        Vec3 origin = getEyePosition();
        Vec3 aim = target.position().add(0, target.getBbHeight() * 0.7, 0);
        Vec3 dir = aim.subtract(origin).normalize();
        float extra = isProne() ? 0.4f : this.hasPose(Pose.CROUCHING) ? 0.9f : 1.5f;
        GunItem.shoot(sl, this, origin, dir, gun.type, false, 0.8f, extra, this::isFriendly, GunItem.mods(this.getMainHandItem()));
        ammo--;
        if (gun.type.automatic) {
            shootCooldown = Math.max(1, gun.type.fireDelay); // hold the trigger like a player
        } else {
            shootCooldown = Math.max(gun.type.fireDelay, 8) + getRandom().nextInt(6);
        }
    }

    // ------------------------------------------------------------ interaction
    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (held.getItem() instanceof GrenadeItem) {
            if (!this.level().isClientSide) {
                hasGrenade = true;
                grenadeCd = Math.min(grenadeCd, 200);
                if (!player.getAbilities().instabuild) held.shrink(1);
                player.displayClientMessage(Component.literal("Bot now has unlimited grenades (one every 40 s)"), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        if (held.getItem() instanceof GunItem gun) {
            if (!this.level().isClientSide) {
                boolean side = gun.type == GunType.PISTOL || gun.type == GunType.DEAGLE;
                int slot = side ? 1 : 0;
                ammoStore[active] = ammo;
                ItemStack old = weapons[slot];
                weapons[slot] = held.copyWithCount(1);
                ammoStore[slot] = gun.type.magSize;
                if (!has(active) || slot == active) {
                    active = slot;
                    ammo = ammoStore[slot];
                    reloadTicks = 0;
                    this.setItemSlot(EquipmentSlot.MAINHAND, weapons[slot]);
                }
                if (!player.getAbilities().instabuild) held.shrink(1);
                if (!old.isEmpty()) player.getInventory().placeItemBackInInventory(old);
                player.displayClientMessage(Component.literal((slot == 1 ? "Sidearm: " : "Primary: ")).append(weapons[slot].getHoverName()), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        if (held.isEmpty()) {
            if (!this.level().isClientSide) {
                if (player.isShiftKeyDown()) {
                    boolean nowAlly = !isAlly();
                    setAlly(nowAlly, player.getUUID());
                    player.displayClientMessage(Component.literal(nowAlly ? "Bot is now ALLY" : "Bot is now ENEMY"), true);
                } else {
                    GunItem g = getGun();
                    player.displayClientMessage(Component.literal((isAlly() ? "Ally" : "Enemy") + " bot | Gun: "
                            + (g == null ? "none" : g.type.id) + " | Sneak+click to switch team"), true);
                }
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    // ------------------------------------------------------------ save
    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Ally", isAlly());
        if (ownerUUID != null) tag.putUUID("Owner", ownerUUID);
        tag.putInt("BotAmmo", ammo);
        ammoStore[active] = ammo;
        for (int i = 0; i < 2; i++) {
            if (!weapons[i].isEmpty()) tag.put("W" + i, weapons[i].save(this.registryAccess()));
            tag.putInt("A" + i, ammoStore[i]);
        }
        tag.putInt("Active", active);
        tag.putBoolean("Grenade", hasGrenade);
        tag.putInt("GrenadeCd", grenadeCd);
        tag.putBoolean("NoLoot", noLoot);
        if (machinePos != null) tag.putLong("Machine", machinePos.asLong());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Ally")) this.entityData.set(ALLY, tag.getBoolean("Ally"));
        if (tag.hasUUID("Owner")) ownerUUID = tag.getUUID("Owner");
        ammo = tag.getInt("BotAmmo");
        if (tag.contains("A0") || tag.contains("W0") || tag.contains("W1")) {
            for (int i = 0; i < 2; i++) {
                weapons[i] = tag.contains("W" + i) ? ItemStack.parse(this.registryAccess(), tag.get("W" + i)).orElse(ItemStack.EMPTY) : ItemStack.EMPTY;
                ammoStore[i] = tag.getInt("A" + i);
            }
            active = tag.getInt("Active");
        } else { // old save: only the main hand gun
            weapons[0] = this.getMainHandItem().copy();
            active = 0;
        }
        hasGrenade = tag.getBoolean("Grenade");
        grenadeCd = tag.getInt("GrenadeCd");
        noLoot = tag.getBoolean("NoLoot");
        if (tag.contains("Machine")) machinePos = BlockPos.of(tag.getLong("Machine"));
        ammoStore[active] = ammo;
        if (has(active)) this.setItemSlot(EquipmentSlot.MAINHAND, weapons[active]);
    }

    // ------------------------------------------------------------ goals
    /** Tactical combat: take cover, peek out to shoot, go prone at range, flee when scared. */
    static class AttackGoal extends Goal {
        private enum S { ADVANCE, TO_COVER, HIDE, PEEK, FLEE, PRONE }

        private final GunBotEntity bot;
        private S state = S.ADVANCE;
        private BlockPos cover;
        private BlockPos peek;
        private int timer;
        private int stateAge;
        private int repath;
        private int coverCooldown;
        private int crowdCheck;
        private boolean crowded;
        private int unseen;

        AttackGoal(GunBotEntity bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity t = bot.getTarget();
            return t != null && t.isAlive() && bot.getGun() != null;
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void start() {
            bot.setAggressive(true);
            set(S.ADVANCE);
            coverCooldown = 0;
        }

        @Override
        public void stop() {
            bot.setAggressive(false);
            bot.getNavigation().stop();
            bot.setPose(Pose.STANDING);
        }

        private void set(S s) {
            state = s;
            stateAge = 0;
            repath = 0;
            switch (s) {
                case HIDE, PEEK -> bot.setPose(Pose.CROUCHING);
                case PRONE -> bot.setPose(Pose.SWIMMING);
                default -> bot.setPose(Pose.STANDING);
            }
        }

        // ---- geometry helpers
        private boolean standable(BlockPos p) {
            Level lv = bot.level();
            return lv.getBlockState(p).getCollisionShape(lv, p).isEmpty()
                    && lv.getBlockState(p.above()).getCollisionShape(lv, p.above()).isEmpty()
                    && lv.getBlockState(p.below()).isFaceSturdy(lv, p.below(), Direction.UP);
        }

        private boolean clear(Vec3 from, Vec3 to) {
            return bot.level().clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, bot))
                    .getType() == HitResult.Type.MISS;
        }

        private static Vec3 eyeAt(BlockPos p) {
            return new Vec3(p.getX() + 0.5, p.getY() + 1.27, p.getZ() + 0.5);
        }

        /** Finds a spot hidden from the target that has a peek spot one or two blocks to the side. */
        private boolean findCover(LivingEntity t) {
            Vec3 te = t.getEyePosition();
            BlockPos base = bot.blockPosition();
            GunItem gun = bot.getGun();
            double maxRange = Math.min(gun.type.range * 0.8, 36.0);
            BlockPos bestC = null, bestP = null;
            double best = Double.MAX_VALUE;
            for (int i = 0; i < 64; i++) {
                BlockPos c = base.offset(bot.getRandom().nextInt(21) - 10, bot.getRandom().nextInt(5) - 2, bot.getRandom().nextInt(21) - 10);
                if (!standable(c)) continue;
                double dt = Math.sqrt(c.distSqr(t.blockPosition()));
                if (dt < 4.0 || dt > maxRange) continue;
                if (clear(te, eyeAt(c))) continue; // still visible -> not cover
                BlockPos pk = null;
                for (int s = 1; s <= 2 && pk == null; s++) {
                    for (Direction d : Direction.Plane.HORIZONTAL) {
                        BlockPos q = c.relative(d, s);
                        if (standable(q) && clear(te, eyeAt(q))) {
                            pk = q;
                            break;
                        }
                    }
                }
                if (pk == null) continue;
                double score = bot.distanceToSqr(c.getX() + 0.5, c.getY(), c.getZ() + 0.5);
                if (score < best) {
                    best = score;
                    bestC = c;
                    bestP = pk;
                }
            }
            if (bestC == null) return false;
            cover = bestC;
            peek = bestP;
            return true;
        }

        private void startFlee(LivingEntity t) {
            set(S.FLEE);
            timer = 100;
            runAway(t);
        }

        private void runAway(LivingEntity t) {
            Vec3 away = DefaultRandomPos.getPosAway(bot, 18, 7, t.position());
            if (away != null) bot.getNavigation().moveTo(away.x, away.y, away.z, 1.4);
        }

        private boolean scared() {
            float hp = bot.getHealth() / bot.getMaxHealth();
            return hp < 0.35f || crowded;
        }

        @Override
        public void tick() {
            LivingEntity t = bot.getTarget();
            GunItem gun = bot.getGun();
            if (t == null || gun == null) return;
            stateAge++;
            if (coverCooldown > 0) coverCooldown--;
            double dist = bot.distanceTo(t);
            boolean see = bot.getSensing().hasLineOfSight(t);
            unseen = see ? 0 : unseen + 1;
            bot.getLookControl().setLookAt(t, 30f, 30f);

            if (--crowdCheck <= 0) { // outnumbered -> afraid
                crowdCheck = 20;
                List<LivingEntity> foes = bot.level().getEntitiesOfClass(LivingEntity.class,
                        bot.getBoundingBox().inflate(22.0), e -> bot.isHostileTo(e) && bot.getSensing().hasLineOfSight(e));
                crowded = foes.size() >= 3;
            }
            if (state != S.FLEE && scared()) {
                startFlee(t);
            }
            // grenade: target ducked behind a wall (or is far away) -> lob one over the top
            if (bot.canThrowGrenade() && dist >= 5.0 && dist <= 30.0 && state != S.FLEE
                    && ((!see && unseen > 5 && unseen < 240) || (see && dist > 12.0 && bot.getRandom().nextInt(160) == 0))) {
                bot.throwGrenade(t, !see);
                return;
            }

            switch (state) {
                case FLEE -> {
                    if (bot.getNavigation().isDone() && timer > 0) runAway(t);
                    if (--timer <= 0 || (!see && unseen > 40)) {
                        // recover out of sight, crouched where we stand
                        cover = bot.blockPosition();
                        set(S.HIDE);
                        timer = scared() ? 200 : 40;
                    }
                }
                case ADVANCE -> {
                    if (see && coverCooldown <= 0) {
                        coverCooldown = 50;
                        if (findCover(t)) {
                            set(S.TO_COVER);
                            return;
                        }
                    }
                    if (see && dist > 24.0 && stateAge > 10 && bot.getRandom().nextInt(30) == 0) {
                        set(S.PRONE);
                        return;
                    }
                    double ideal = Math.min(gun.type.range * 0.5, 16.0);
                    if (see && dist <= ideal) {
                        bot.getNavigation().stop();
                    } else if (--repath <= 0) {
                        repath = 10;
                        bot.getNavigation().moveTo(t, 1.1);
                    }
                    if (see && dist <= Math.min(gun.type.range, 40.0)) bot.tryShoot(t);
                }
                case PRONE -> {
                    bot.getNavigation().stop();
                    if (see && dist <= Math.min(gun.type.range, 48.0)) bot.tryShoot(t);
                    if (dist < 16.0 || unseen > 60 || bot.hurtTime > 0 && stateAge > 20) set(S.ADVANCE);
                }
                case TO_COVER -> {
                    if (cover == null) { set(S.ADVANCE); return; }
                    if (--repath <= 0) {
                        repath = 8;
                        bot.getNavigation().moveTo(cover.getX() + 0.5, cover.getY(), cover.getZ() + 0.5, 1.35);
                    }
                    // shoot while running only if clearly visible and close
                    if (see && dist < 12.0 && bot.getRandom().nextInt(6) == 0) bot.tryShoot(t);
                    if (bot.distanceToSqr(cover.getX() + 0.5, cover.getY(), cover.getZ() + 0.5) < 1.6) {
                        bot.getNavigation().stop();
                        set(S.HIDE);
                        timer = 20 + bot.getRandom().nextInt(30);
                    } else if (stateAge > 140) {
                        set(S.ADVANCE);
                    }
                }
                case HIDE -> {
                    bot.getNavigation().stop();
                    if (bot.ammoLeft() < gun.type.magSize / 3) bot.reloadNow();
                    if (bot.tickCount % 20 == 0 && bot.getHealth() < bot.getMaxHealth() && !see) bot.heal(1.0f);
                    if (see && cover != null && clear(t.getEyePosition(), eyeAt(cover))) { // cover compromised
                        if (findCover(t)) { set(S.TO_COVER); return; }
                        startFlee(t);
                        return;
                    }
                    if (--timer <= 0 && !bot.isReloading() && !scared()) {
                        if (peek == null || !standable(peek)) {
                            if (!findCover(t)) { set(S.ADVANCE); return; }
                        }
                        set(S.PEEK);
                        timer = 14 + bot.getRandom().nextInt(14);
                    }
                }
                case PEEK -> {
                    if (peek == null) { set(S.ADVANCE); return; }
                    double pd = bot.distanceToSqr(peek.getX() + 0.5, peek.getY(), peek.getZ() + 0.5);
                    if (pd > 0.5) {
                        if (--repath <= 0) {
                            repath = 6;
                            bot.getNavigation().moveTo(peek.getX() + 0.5, peek.getY(), peek.getZ() + 0.5, 1.4);
                        }
                    } else {
                        bot.getNavigation().stop();
                    }
                    if (see && dist <= Math.min(gun.type.range, 44.0)) {
                        bot.tryShoot(t);
                        timer--;
                    }
                    if (timer <= 0 || bot.ammoLeft() <= 0 || (bot.hurtTime > 0 && stateAge > 6) || stateAge > 90) {
                        set(S.TO_COVER);
                    }
                }
            }
        }
    }

    static class FollowOwnerGoal extends Goal {
        private final GunBotEntity bot;
        private int repath;

        FollowOwnerGoal(GunBotEntity bot) {
            this.bot = bot;
            this.setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (!bot.isAlly() || bot.getTarget() != null) return false;
            Player o = bot.getOwner();
            return o != null && bot.distanceToSqr(o) > 64.0;
        }

        @Override
        public boolean canContinueToUse() {
            if (!bot.isAlly() || bot.getTarget() != null) return false;
            Player o = bot.getOwner();
            return o != null && bot.distanceToSqr(o) > 12.0;
        }

        @Override
        public void tick() {
            Player o = bot.getOwner();
            if (o == null) return;
            if (--repath <= 0) {
                repath = 10;
                if (bot.distanceToSqr(o) > 1024.0) {
                    bot.teleportTo(o.getX(), o.getY(), o.getZ());
                } else {
                    bot.getNavigation().moveTo(o, 1.2);
                }
            }
        }
    }
}
