package com.example.gunsmod;

public final class Paints {
    public static final String[] NAMES = {"Graphite", "Desert Tan", "Jungle Camo", "Arctic White",
            "Crimson Red", "Ocean Blue", "Gold Plated"};
    public static final int[] COLORS = {0xFF3C3C42, 0xFFB0925C, 0xFF4A6234, 0xFFE1E4E8,
            0xFFA62626, 0xFF3060AA, 0xFFD6AA32};
    public static final int COUNT = NAMES.length;

    private Paints() {}
}
