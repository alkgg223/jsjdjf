# Guns and Bots v4 — what changed

* Weapons: real 3D OBJ models (profile-extruded, round barrels, angled grips, rails, sights) instead of cuboids.
  Generated per gun x 7 paints; attachments are separate parts drawn by `GunItemRenderer`.
* Optics (7): Red Dot, 4x, Holographic, ACOG 3x, 8x Long Range, Thermal (+ sniper built-in) with distinct reticles / lens views.
* Muzzle (5): Suppressor, Compensator, Flash Hider, Muzzle Brake, Bayonet.
* Underbarrel (4): Vertical Grip, Angled Grip, Laser Module, Bipod.
* Ammo types (4): FMJ, Hollow Point, Armor Piercing, Incendiary.
* New UI: Workbench (scrolling list, 3D preview, Requires row, Craft / x5) and Customizer (5 categories, rotatable 3D preview, stats bars).
* New HUD: big ammo counter, reserve, fire mode, armor bar, hit counter ("N dmg / M hits"), floating damage numbers, hit marker, custom crosshair.
* Particles: muzzle flash / smoke / explosion frames sliced from the supplied pixel-art sheet (exp_0..17).

## v4.1
* Fixed weapons facing backwards (models are now mirrored so the muzzle points forward in hand).
* Redesigned the M249 and pump shotgun models.
* Bots: take cover behind walls, peek out to shoot a short burst, return, reload while hidden; go prone at long range;
  crouch (smaller hitbox) while peeking; flee when health < 35% or outnumbered (3+ visible enemies) and recover out of sight.

## v4.2
* RPG explosions no longer break blocks. New Grenade item (bouncing frag, 2.5 s fuse, damages entities only, no block damage).
* Bots: carry primary + pistol + grenade and swap between them; give a grenade to a bot = unlimited, one throw per 40 s,
  lobbed over walls at targets that hid. Attachments (suppressor etc.) now apply to bot weapons (sound, fx, stats).
* Automatic guns fire continuous bursts for bots. Ally bots no longer follow the player.
* White Crystal: right-click an armed bot to store it -> Purple Crystal; right-click the ground with it to respawn the same bot (reusable).
* Bot Respawner block: put a Purple Crystal inside, set max bots (1-20); dead bots respawn beside the block.
